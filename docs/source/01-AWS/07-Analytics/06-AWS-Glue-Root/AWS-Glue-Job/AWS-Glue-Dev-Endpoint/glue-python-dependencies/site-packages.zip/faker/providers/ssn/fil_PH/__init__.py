from ..en_PH import Provider as EnPhSsnProvider


class Provider(EnPhSsnProvider):
    """No difference from SSN Provider for en_PH locale"""

    pass
